from flask import Flask, request, jsonify
from flask_cors import CORS
from pymongo import MongoClient
from dotenv import load_dotenv
from bson import ObjectId
import os

load_dotenv()

app = Flask(__name__)
CORS(app)

client = MongoClient(os.getenv("MONGO_URI"))
db = client["event_management"]

users = db["users"]
events = db["events"]
registrations = db["registrations"]

@app.route('/')
def home():
    return "MongoDB Connected Successfully"

# Register
@app.route('/register', methods=['POST'])
def register():
    data = request.json
    users.insert_one({
        "name": data['name'],
        "email": data['email'],
        "password": data['password'],
        "role": "user"
    })
    return jsonify({"message": "User Registered Successfully"})

# Login
@app.route('/login', methods=['POST'])
def login():
    data = request.json
    user = users.find_one({"email": data['email'], "password": data['password']})
    if user:
        user['_id'] = str(user['_id'])
        return jsonify(user)
    return jsonify({"message": "Invalid credentials"}), 401

# Create Event
@app.route('/event/create', methods=['POST'])
def create_event():
    data = request.json
    events.insert_one({
        "name": data['name'],
        "date": data['date'],
        "location": data['location'],
        "seats": data['seats'],
        "registered_users": []
    })
    return jsonify({"message": "Event Created Successfully"})

# Get All Events
@app.route('/events', methods=['GET'])
def get_events():
    all_events = list(events.find())
    for e in all_events:
        e['_id'] = str(e['_id'])
    return jsonify(all_events)

# Delete Event
@app.route('/event/delete/<event_id>', methods=['DELETE'])
def delete_event(event_id):
    events.delete_one({"_id": ObjectId(event_id)})
    return jsonify({"message": "Event Deleted"})

# Register for Event
@app.route('/event/register', methods=['POST'])
def register_event():
    data = request.json
    existing = registrations.find_one({
        "user_id": data['user_id'],
        "event_id": data['event_id']
    })
    if existing:
        return jsonify({"message": "Already Registered!"}), 400
    registrations.insert_one({
        "user_id": data['user_id'],
        "event_id": data['event_id']
    })
    return jsonify({"message": "Registered Successfully!"})

# Get User Registrations
@app.route('/registrations/<user_id>', methods=['GET'])
def get_registrations(user_id):
    regs = list(registrations.find({"user_id": user_id}))
    for r in regs:
        r['_id'] = str(r['_id'])
    return jsonify(regs)

if __name__ == '__main__':
    app.run(debug=True)